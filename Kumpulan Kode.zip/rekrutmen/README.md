# DSS Rekrutmen anggota

Rekrutmen anggota baru UKM Kesenian STMIK AKAKOM Yogyakarta

![Screenshot Home](screenshot.png "Screenshot Home")

## Cara menggunakan
1. Letakkan folder didalam root direktori web server
2. Import `database.sql`
3. Kunjungi [localhost/simple-recruitment-dss-ahp](http://localhost/simple-recruitment-dss-ahp)
4. Login
  - Operator
    - username : operator
    - password : operator
  - Wakil Ketua
    - username : wakil
    - password : wakil
  - Ketua Umum
    - username : ketua
    - password : ketua


![Relasi Tabel](relasi.png "Relasi Tabel")
