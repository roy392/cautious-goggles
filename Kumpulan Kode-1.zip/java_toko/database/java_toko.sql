/*
SQLyog Enterprise - MySQL GUI v8.18 
MySQL - 5.1.41 : Database - dbtoko
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`dbtoko` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dbtoko`;

/*Table structure for table `barang` */

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `kd_barang` varchar(6) NOT NULL,
  `nm_barang` varchar(20) NOT NULL,
  `harga` varchar(30) NOT NULL,
  `stok` varchar(30) NOT NULL,
  PRIMARY KEY (`kd_barang`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `barang` */

insert  into `barang`(`kd_barang`,`nm_barang`,`harga`,`stok`) values ('B001','Sabun Nuvo','1000','10'),('B002','Shampo','500','10'),('B003','Pepsodent','1500','19'),('B004','Gula 1 Kg','7500','11');

/*Table structure for table `pelanggan` */

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `kd_pelanggan` varchar(6) NOT NULL,
  `nm_pelanggan` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `notlp` varchar(13) NOT NULL,
  PRIMARY KEY (`kd_pelanggan`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `pelanggan` */

insert  into `pelanggan`(`kd_pelanggan`,`nm_pelanggan`,`alamat`,`notlp`) values ('P001','Fahruddin','Bangil','083837288399'),('P002','Iklima N','Bangil','0827636377'),('P003','Novi Santoso','Pasuruan','08374747748'),('P004','Mahros','Pasuruan','083833117951');

/*Table structure for table `pembelian` */

DROP TABLE IF EXISTS `pembelian`;

CREATE TABLE `pembelian` (
  `no_transaksi` varchar(30) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `kd_supplier` varchar(30) NOT NULL,
  `kd_barang` varchar(30) NOT NULL,
  `harga` varchar(20) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  `totalharga` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `pembelian` */

insert  into `pembelian`(`no_transaksi`,`tgl_transaksi`,`kd_supplier`,`kd_barang`,`harga`,`jumlah`,`totalharga`) values ('001','2013-06-11 00:00:00','S002','B003','1500','23','34500');

/*Table structure for table `penjualan` */

DROP TABLE IF EXISTS `penjualan`;

CREATE TABLE `penjualan` (
  `no_transaksi` varchar(30) NOT NULL,
  `tgl_transaksi` datetime NOT NULL,
  `kd_barang` varchar(30) NOT NULL,
  `harga` varchar(20) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  `totalharga` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `penjualan` */

insert  into `penjualan`(`no_transaksi`,`tgl_transaksi`,`kd_barang`,`harga`,`jumlah`,`totalharga`) values ('001','2013-06-12 00:00:00','B002','500','2','1000'),('001','2013-06-12 00:00:00','B003','1500','16','24000'),('001','2013-06-12 00:00:00','B004','7500','1','7500'),('004','2013-06-12 00:00:00','B002','500','4','2000'),('004','2013-06-12 00:00:00','B003','1500','2','3000'),('003','2013-06-06 00:00:00','B002','500','2','1000');

/*Table structure for table `supplier` */

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `kd_supplier` varchar(6) NOT NULL,
  `nm_supplier` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `notlp` varchar(13) NOT NULL,
  PRIMARY KEY (`kd_supplier`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `supplier` */

insert  into `supplier`(`kd_supplier`,`nm_supplier`,`alamat`,`notlp`) values ('S001','Toko Barokah','Pasuruan','0847373447343'),('S002','Toko Indah','Surabaya','031-789453'),('S003','Supermart','Bangil','08323245556');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
